const peopleData = require('./people');
const stockData = require('./stocks');

module.exports = {
    people: peopleData,
    stocks: stockData
};