module.exports = {
    characters: require('./characters')
  };